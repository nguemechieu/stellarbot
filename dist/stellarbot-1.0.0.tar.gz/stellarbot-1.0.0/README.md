################################
#   StellarBot
################################

## Description
   - Stellarbot is a professionals trading bot that allows you to execute commands on your network using the standard protocol on the stellar network (https://stellar.expert/explorer/public/network-activity).
