
# Welcome to  StellarBot
![stellarbot](src/images/stellarbot.png)


## Description

   - Stellarbot is a professional trading bot for stellar Network digital ledger.Its allows you to execute trade  on your own stellar  network using the standard protocol on the Stellar ecosystem. (https://stellar.expert/explorer/public/network-activity).


### Installation


## Docker Image


## Commands




## Links



 

